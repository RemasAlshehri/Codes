#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "discounts.h"
#include <fstream> 
using namespace std;

namespace old_price{
	void pr(double y){
		double x1;
		cout<<"the ticket befor discount is: "<<y<<endl;
		
		cout<<"how many people are you?";
		cin>>x1;
		
		
		y=(x1*(0.5*200)-x1*(-200));
		
		cout<<"the tiket after discount is: "<<y<<endl;
		
		cout<<endl<<"the total amount is: "<<y<<"SR"<<endl;
	 pay();
	}
}
void test(int &b){
	b=b+4;
}
int i,j;//global variable

void sort(){
	 int  size=4; 
 string data[size]={"Tuesday","Thursday","Friday","Saturday"}, name,temp;
 bool ordered=false;
 cout<<"##The days thats the waterland open##: ";
 for (i=0;i<size;i++)
 cout<<data[i];
 if (size < 2)
 cout<<"nothing to sort!!";
 else
 {
 for(i = 0; i < size-1 && ordered==false ; ++i) 
 {
ordered=true;
for(j = 0; j < size-1;++j)
 if(data[j].compare(data[j+1])>0)
 {
ordered=false;
 temp = data[j];
 data[j] = data[j+1];
 data[j+1] = temp;
 }
 }
 cout<<"\nthe days in  alphabetic ordered :\n";

 for ( i=0;i<size;i++)
 
 cout<<endl<<"**"<<data[i]<<"**";
 }
}


struct games{
	int game1;
	int game2;
	int game3;
	int game4;
	int game5;
};

int main(){
	double x,q,y=200,*p;
	double game;
	int size,x1,k ,w,price,e; 
	p=&y;
	
	cout<<"\n                         ********** Water land **********\n ";
	
   cat();
   cout<<endl;
   
    sort();
    cout<<endl;
    
   	fam();
   	cout<<endl;
   
   
   	cout<<"Enter your choice:";
  
    char r;
    cin>>r;
    cout<<endl<<endl;
    if (r=='a'){
    	cout<<"you have  20% discount :)"<<endl;
    	cout<<endl<<endl;
    	cout<<"the ticket before discount is : "<<*p<<endl;
    	cout<<endl;
    	y=family(q);
    	
    	cout<<"the ticket after discount is: "<<y<<endl;
    	cout<<endl<<"the total amount is: "<<y <<"SR"<<endl;
	 pay();
	 
	 
    	
    	
	}
	else if (r=='b'){
		cout<<"you have 50% discount ;)"<<endl;
		cout<<endl;
		old_price::pr(y);
		cout<<endl;
	}
	else if (r=='c'){
		cout<<"you have 10% discount :>"<<endl;
		cout<<endl;
		cout<<"the ticket before discount is : "<<*p<<endl;
		cout<<endl;
		
		y=kids(q);
		
		cout<<"the ticket after discount is: "<<y<<endl;
		
		cout<<endl<<"the total amount is: "<<y <<"SR"<<endl;
	 pay();
	 
		
	}
	else if (r=='d'){
		cout<<"you have no discount :<"<<endl;
		
		cout<<endl;
		cout<<"the ticket price is: "<<others(q)<<endl;
		cout<<endl<<"the total amount is: "<< others(q)<<"SR"<<endl;
	 pay();
	}
	 cout<<"Enter 1  or 2 :";
	 cin>>w;
	 
	 if (w==1){
	 	cout<<"please, enter the money here: ";
	 	cin>>price;
	 }
	 else if (w==2){
	 	cout<<"please put your card on the machine."<<endl;}  
	cout<<endl<<endl;

string menu ="\n Please choose the servise: \n\t1-Add person\'s' name and age \n\t2-Update person\'s name  \n\t3-Print person\'s name and age \n\t4-Delete person\'s name  \n\t5-Search person\'s age \n\t6-End\n ";
	const int SIZE=100;
	
	string person[SIZE][2];
	int numitm=-1;
	int choice;
	string name, age ,namesearch; 
	
	cout<<menu;
	cin>>choice;
	while(choice!=6)
	{
	switch (choice)
	{
	case 1:
	if(numitm<SIZE-1)
	{
	cout<<"Enter name and age: ";
	cin>>name>>age;
	numitm++;
	person[numitm][0]=name;
	person[numitm][1]=age;
	bool ordered= false;	
	}
    else
	cout<<"\nThe array is full, you need to delete items to add";
	break;
	case 2:
	cout<<"\nEnter person name to update: ";
	cin>>name;
	for(i=0 ;i<=numitm;i++)
	if(person[i][0]==name)
	{
	cout<<"Enter new age: ";
	cin>>age;
	person[i][1]=age;
    cout<<"\nperson updated"<<(i+1)<<"\t"<<person[i][0]<<"\t"<<person[i][1];
	break;
	}
	break;
    case 3:
	for(i=0 ; i<=numitm ;i++)
    cout<<"\nperson"<<(i+1)<<"\t"<<person[i][0]<<"\t"<<person[i][1];
	cout<<endl;
	break;
	case 4:
	if(numitm>=0)
	{
    string name , newage;
	cout<<"\nEnter person name to delete: ";
	cin>>name;
	for(i=0;i<=numitm;i++)
	if(person[i][0]==name)
	{
	for(  j=i ;j<numitm ; j++)
	{
	person[j][0]=person[j+1][0];
	person[j][1]=person[j+1][1];
	}
	numitm--;
	cout<<"\nPerson deleted.";					
	}
	break;
	}
	break;
	case 5 :
				
	cout<<"\nPerson name ? \n";
	cin>>namesearch;
    for(int i=0;i<=numitm;i++){
	if(person[i][0] == namesearch)
	{
	cout<<"\n"<<person[i][0]<<"'s age :\n";
	cout<<person[i][1];
	 }break;}
	break;
	default:
	cout<<"\nIncorrect menu option.";
	}
	cout<<menu;
	cin>>choice;
}
cout<<"\n                             Welcome to water land  \n";

	games g;
	cout<<"\npleas enter the name of the game that you want to play:\n";
	cout<<"1-water roller coaster game\n";
	cout<<"2-water train game\n";
	cout<<"3-water swings game\n";
	cout<<"4-water gun\n";
	cout<<"5-the pool race\n";
	cout<<"6-water washer toss\n";
	cout<<"7-water Ballon fight\n";
	cout<<"8-water slider\n"<<endl;

	cout<<"Enter 5 numbers of the games you want to play (!!ONLY 5 QAMES!!) : ";
		
	cin>>g.game1;
	cin>>g.game2;
	cin>>g.game3;
	cin>>g.game4;
	cin>>g.game5;
	
	



	cout<<endl;
	cout<<"                           The registration of "<<g.game1<<","<<g.game2<<","<<g.game3<<","<<g.game4<<","<<g.game5<<" is done!\n"<<endl;

	int random=rand()*5;
	

	cout<<"The game price for today is: "<<random <<" SR\n";
	cout<<endl<<endl;
	cout<<endl<<"the total amount is: "<<random <<"SR"<<endl;
	 pay();
	 cout<<endl;
	 
	 
	 cout<<"Enter 1  or 2 :";
	 cin>>w;
	 
	 if (w==1){
	 	cout<<"please, enter the money here: ";
	 	cin>>price;
	 }
	 else if (w==2){
	 	cout<<"please put your card on the machine."<<endl;
	 }
	
		
		cout<<endl<<endl;
		
	int s;
	cout<<"Enter your entrance time \"it doesn't matter if it's AM or PM\" :";
	cin>>s;
	test(s);
	cout<<endl;
	cout<<"you have to exist at: "<<s<<endl;
	
	
	star();
	cout<<endl<<endl;
	cout<<endl;
	string opinion;

	ofstream outfile , appfile;   //output of the file
	ifstream infile;  //create input file object named infile

	cout<<"Write your comments and opinion about our service:";
	cin.ignore();
	getline(cin,opinion);

	infile.open("paperfile.txt",ios::in);
	outfile.open("paperfile.txt",ios::out);
	appfile.open("paperfile.txt",ios::app);
	

	if(infile.is_open()==true &&outfile.is_open()==true && appfile.is_open()==true){
		
		 appfile<<"Write your comments and opinion about our service:"<<endl;
	   
		
	appfile<<opinion<<endl;
	
	cout<<"file is opened! "<<endl;
	appfile<<"Copied successfully�"<<endl;
	infile.close() ; outfile.close();  appfile.close();
	
	}
	
	cout<<endl<<endl;
	feeds(0);
	
	
	return 0;
}
	
